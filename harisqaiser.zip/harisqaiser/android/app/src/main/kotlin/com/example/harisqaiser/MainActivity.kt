package com.example.harisqaiser

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
